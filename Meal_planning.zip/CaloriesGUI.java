import javax.swing.*;
import java.awt.*;

public class CaloriesGUI extends JFrame {

    private JPanel panel;
	private JLabel imgLabel;
    private ImageIcon img, icon;


    public CaloriesGUI(double dailyCalories, double carbohydrate, double protein, double fat) {
        // Set the title, size, and default close operation for the JFrame
        setTitle("Daily Nutrition");
        setSize(1000, 800);  // Adjusted size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a JPanel and set its layout to a vertical BoxLayout
        panel = new JPanel();
        panel.setLayout(null);
		
		panel.setBackground(Color.BLACK);
		
		icon = new ImageIcon("pyramid.png");
		JLabel picLabel = new JLabel(icon);
		picLabel.setBounds(220,430,100,100);
		picLabel.setBorder(null);
		panel.add(picLabel);
		
		img = new ImageIcon("Food2.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(400, 0, 1000, 800);
        panel.add(imgLabel);
		
        JLabel resultLabel = new JLabel("Daily Calories: " + dailyCalories);
        resultLabel.setForeground(Color.WHITE); // Set text color
        resultLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 30));// Set font size
        resultLabel.setBounds(80, 150, 400, 40); // Set bounds
        panel.add(resultLabel);

        JLabel carbLabel = new JLabel("Carbohydrate: " + carbohydrate + " grams");
        carbLabel.setForeground(Color.WHITE); // Set text color
        carbLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 26)); // Set font size
        carbLabel.setBounds(80, 210, 450, 36); // Set bounds
        panel.add(carbLabel);

        JLabel fatLabel = new JLabel("Fat: " + fat + " grams");
        fatLabel.setForeground(Color.WHITE); // Set text color
        fatLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 26)); // Set font size
        fatLabel.setBounds(80, 270, 450, 36); // Set bounds
        panel.add(fatLabel);

        JLabel proteinLabel = new JLabel("Protein: " + protein + " grams");
        proteinLabel.setForeground(Color.WHITE); // Set text color
        proteinLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 26)); // Set font size
        proteinLabel.setBounds(80, 330, 450, 36); // Set bounds
        panel.add(proteinLabel);

        // Add a button to proceed to the next GUI (MealsGUI)
        JButton mealsButton = new JButton("Select Meal");
        mealsButton.addActionListener(e -> showMealsGUI());
        mealsButton.setBounds(270, 600, 150, 40);
		mealsButton.setFont(new Font("Monaco", Font.ITALIC, 20));
        mealsButton.setBackground(Color.ORANGE);
        mealsButton.setForeground(Color.BLACK);
        panel.add(mealsButton);

        // Add a button to go back to the previous GUI (InputGUI)
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showInputGUI());
        backButton.setBounds(100, 600, 150, 40);
		backButton.setFont(new Font("Monaco", Font.ITALIC, 20));
        backButton.setBackground(Color.ORANGE);
        backButton.setForeground(Color.BLACK);
        panel.add(backButton);

        // Set the preferred size of the panel and add it to a scroll pane
        panel.setPreferredSize(new Dimension(800, 600)); // Set preferred size
        JScrollPane scrollPane = new JScrollPane(panel);
        setContentPane(scrollPane);
    }

    private void showMealsGUI() {
        // Create and display the MealsGUI
        MealsGUI mealsGUI = new MealsGUI();
        mealsGUI.setVisible(true);

        // Close the CaloriesGUI after proceeding
        this.dispose();
    }

    private void showInputGUI() {
        // Create and display the InputGUI
        InputGUI inputGUI = new InputGUI();
        inputGUI.setVisible(true);

        // Close the CaloriesGUI after going back
        this.dispose();
    }

    public static void main(String[] args) {
        // Example usage in the main method
        javax.swing.SwingUtilities.invokeLater(() -> {
            CaloriesGUI caloriesGUI = new CaloriesGUI(2000, 250, 75, 90);
            caloriesGUI.setVisible(true);
        });
    }
}
