import java.util.ArrayList;
import java.util.List;

public class Users {
    private List<User> userList;

    public Users() {
        userList = new ArrayList<>();
    }

    public void addUser(User user) {
        userList.add(user);
    }

    public boolean userExists(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    public boolean authenticateUser(String username, String password) {
        for (User user : userList) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
	
	
     // Add this method to update the password
    public void updatePassword(String username, String newPassword) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                user.setPassword(newPassword);
                return;
            }
        }
    }
	
	
    public List<User> getUserList() {
        return userList;
    }
}
