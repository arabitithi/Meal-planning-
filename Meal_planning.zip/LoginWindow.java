import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
public class LoginWindow extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private Users users;
	private JLabel imgLabel;
    private ImageIcon img, icon,icon2;
	
    public LoginWindow(Users users) {
		
        // Set frame properties
        setTitle("Login");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JLabel titleLabel = new JLabel("Sign In");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 50));
        titleLabel.setBounds(230, 50, 400, 100);
        titleLabel.setForeground(Color.WHITE);
		
        // Set background color to black
        getContentPane().setBackground(Color.BLACK);
		
		icon = new ImageIcon("User2.png");
		JLabel picLabel = new JLabel(icon);
		picLabel.setBounds(260,150,100,100);
		picLabel.setBorder(null);
		
		icon2 = new ImageIcon("Ramen.png");
		JLabel picLabel2 = new JLabel(icon2);
		picLabel2.setBounds(470,100,512,512);
		picLabel2.setBorder(null);

        // Create panel
        JPanel panel = new JPanel(null); // Use null layout
        // Set panel background color
		
        panel.setBackground(Color.BLACK);
        // Create components
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel registerLabel = new JLabel("Don't have an account?");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        JButton showPasswordButton = new JButton("Show");
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");
        JButton exitButton = new JButton("Exit");
		
        // Set button colors
        loginButton.setBackground(Color.ORANGE);
        registerButton.setBackground(Color.CYAN);
        registerButton.setForeground(Color.BLACK);
        exitButton.setBackground(Color.ORANGE);
        exitButton.setForeground(Color.BLACK);
		
        // Set font and foreground color for labels
        Font labelFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameLabel.setFont(labelFont);
        usernameLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(labelFont);
        passwordLabel.setForeground(Color.WHITE);
        registerLabel.setFont(labelFont);
        registerLabel.setForeground(Color.WHITE);
		
        // Set font and other properties for text fields
        Font textFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameField.setFont(textFont);
        passwordField.setFont(textFont);
        passwordField.setEchoChar('*');
		
        // Set properties for buttons
        showPasswordButton.setBackground(Color.CYAN);
        showPasswordButton.setForeground(Color.BLACK);
        loginButton.setBackground(Color.ORANGE);
        loginButton.setForeground(Color.BLACK);
        registerButton.setBackground(Color.ORANGE);
        registerButton.setForeground(Color.BLACK);
        exitButton.setBackground(Color.RED);
        exitButton.setForeground(Color.BLACK);
		
        // Set bounds for components
        usernameLabel.setBounds(65, 300, 200, 30);
        usernameField.setBounds(200, 300, 200, 35);
        passwordLabel.setBounds(65, 350, 200, 30);
        passwordField.setBounds(200, 350, 200, 35);
        showPasswordButton.setBounds(400, 350, 70, 35);
        loginButton.setBounds(200, 400, 130, 35);
        registerLabel.setBounds(65, 500, 300, 30);
        registerButton.setBounds(340, 500, 140, 35);
        exitButton.setBounds(340, 400, 130, 35);
		
        // Create an "Update Pass" button
        JButton updatePassButton = new JButton("Update Pass");
        // Set button colors
        updatePassButton.setBackground(Color.ORANGE);
        updatePassButton.setForeground(Color.BLACK);
		
        // Set font and other properties for buttons
        Font buttonFont = new Font("Monaco", Font.ITALIC, 17);
        updatePassButton.setFont(buttonFont);
        loginButton.setFont(buttonFont);
        registerButton.setFont(buttonFont);
        exitButton.setFont(buttonFont);
		showPasswordButton.setFont(new Font("Monaco", Font.ITALIC, 14));
		
        // Set bounds for the update button
        updatePassButton.setBounds(200, 550, 200, 40);
		
        // Add components to the panel
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(showPasswordButton);
        panel.add(loginButton);
        panel.add(registerLabel);
        panel.add(registerButton);
        panel.add(exitButton);
        panel.add(updatePassButton);
        panel.add(titleLabel);
		panel.add(picLabel);
		panel.add(picLabel2);
		
        // Add panel to the frame
        add(panel);
        // Initialize user list with sample users
        this.users = users;
        this.users.addUser(new User("Tithi", "123"));
        this.users.addUser(new User("Drishti", "456"));
        // Add action listeners
        showPasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Toggle password visibility
                passwordField.setEchoChar(passwordField.getEchoChar() == '*' ? '\0' : '*');
            }
        });
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement login logic using the user list
                String username = usernameField.getText();
                char[] password = passwordField.getPassword();
                if (username.isEmpty() || password.length == 0) {
                    //JOptionPane.showMessageDialog(LoginWindow.this, "Please, fill up to Login!");
                } else {
                    if (users.authenticateUser(username, new String(password))) {
                        JOptionPane.showMessageDialog(LoginWindow.this, "Login successful!");
                    } else {
                        JOptionPane.showMessageDialog(LoginWindow.this, "Invalid username or password");
                    }
                    // Clear the fields after login attempt
                    usernameField.setText("");
                    passwordField.setText("");
                }
            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the RegisterWindow when the Register button is clicked
                RegisterWindow registerWindow = new RegisterWindow(LoginWindow.this, users);
                registerWindow.setVisible(true);
                // Close the LoginWindow
                dispose();
            }
        });
        // Add action listener for the "Update Pass" button
        updatePassButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the UpdatePasswordWindow when the "Update Pass" button is clicked
                UpdatePasswordWindow updatePasswordWindow = new UpdatePasswordWindow(LoginWindow.this, users);
                updatePasswordWindow.setVisible(true);
                // Close the LoginWindow
                dispose();
            }
        });
        // Add action listener for the "Exit" button
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Exit the application when the "Exit" button is clicked
                System.exit(0);
            }
        });
		
		// Inside the LoginWindow class, modify the loginButton.addActionListener as follows:
     loginButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement login logic using the user list
            String username = usernameField.getText();
            char[] password = passwordField.getPassword();
            if (username.isEmpty() || password.length == 0) {
                //JOptionPane.showMessageDialog(LoginWindow.this, "Please, fill up to Login!");
            } else {
                if (users.authenticateUser(username, new String(password))) {
                    JOptionPane.showMessageDialog(LoginWindow.this, "Login successful!");

                    // Open the InputGUI after successful login
                    InputGUI inputGUI = new InputGUI();
                    inputGUI.setVisible(true);

                    // Close the LoginWindow
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(LoginWindow.this, "Invalid username or password");
                }
                // Clear the fields after login attempt
                usernameField.setText("");
                passwordField.setText("");
            }
        }
    });

    }
}