import javax.swing.*;
import java.awt.*;

public class MealNamesGUI extends JFrame {
	
	private JLabel imgLabel;
    private ImageIcon img;

    public MealNamesGUI(String mealType) {
		
        setTitle("Select " + mealType + " Meal");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.BLACK);
		
		img = new ImageIcon("Food6.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(410, 0, 1000, 800);
        panel.add(imgLabel);

        JLabel titleLabel = new JLabel("Select Your " + mealType + " Meal");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 34));
        titleLabel.setBounds(80, 12, 450, 60);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);

        String[] mealOptions = getMealOptions(mealType);

        int yCoordinate = 90; // Initial y-coordinate for buttons

        for (String meal : mealOptions) {
            JButton mealButton = createMealButton(meal);
            mealButton.setBounds(150, yCoordinate, 250, 34);
			mealButton.setFont(new Font("Monaco", Font.ITALIC, 15));
            mealButton.setBackground(Color.ORANGE);
            mealButton.setForeground(Color.BLACK);
            panel.add(mealButton);

            yCoordinate += 65; // Increase y-coordinate for the next button
        }

        // Add a back button
        JButton backButton = new JButton("Back to Meals");
        backButton.setBounds(150, yCoordinate, 250, 34);
		backButton.setFont(new Font("Monaco", Font.ITALIC, 18));
        backButton.setBackground(Color.BLUE);
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> goBackToMealsGUI());
        panel.add(backButton);

        add(panel);
        setLocationRelativeTo(null); // Center the JFrame on the screen
    }

        private JButton createMealButton(String meal) {
        JButton mealButton = new JButton(meal);
        mealButton.addActionListener(e -> showMealDetails(meal));
        return mealButton;
    }

    private String[] getMealOptions(String mealType) {
        switch (mealType) {
            case "Breakfast":
                return new String[]{"Oatmeal with Fruits", "Scrambled Eggs", "Smoothie Bowl", "Pancakes", "Avocado Toast",
                        "Greek Yogurt with Berries", "Granola Parfait", "Bagel with Cream Cheese", "Breakfast Burrito"};
            case "Lunch":
                return new String[]{"Grilled Chicken Salad", "Vegetable Wrap", "Quinoa Bowl", "Caprese Sandwich", "Caesar Salad",
                        "Chicken Caesar Wrap", "Mediterranean Salad", "Turkey Club Sandwich", "Vegetarian Pizza"};
            case "Dinner":
                return new String[]{"Salmon with Asparagus", "Pasta Primavera", "Stir-Fried Tofu", "Chicken Alfredo", "Mushroom Risotto",
                        "Beef Stir-Fry", "Shrimp Scampi", "Vegetable Lasagna", "Honey Glazed Chicken"};
            default:
                return new String[0];
        }
    }

    private void showMealDetails(String selectedMeal) {
        MealDetailsGUI mealDetailsGUI = new MealDetailsGUI(selectedMeal);
        mealDetailsGUI.setVisible(true);
        this.dispose(); // Close the MealNamesGUI after proceeding
    }

    private void goBackToMealsGUI() {
        MealsGUI mealsGUI = new MealsGUI();
        mealsGUI.setVisible(true);
        this.dispose(); // Close the MealNamesGUI and go back to MealsGUI
    }

}
