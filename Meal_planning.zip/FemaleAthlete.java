// FemaleAthlete.java
public class FemaleAthlete extends Person {
    private String activityLevel;

    public FemaleAthlete(int age, double height, double weight, String sport, String activityLevel) {
        super(age, height, weight, sport);
        this.activityLevel = activityLevel;
    }

    @Override
    public double calculateDailyCalories() {
        double bmr = 10 * getWeight() + 6.25 * getHeight() - 5 * getAge() - 161;
        double activityFactor = getActivityFactor();
        return bmr * activityFactor;
    }

    @Override
    public double calculateCarbohydrate() {
        return calculateDailyCalories() * 0.5 / 4; // Assuming 50% of calories from carbs
    }

    @Override
    public double calculateProtein() {
        return calculateDailyCalories() * 0.2 / 4; // Assuming 20% of calories from protein
    }

    @Override
    public double calculateFat() {
        return calculateDailyCalories() * 0.3 / 9; // Assuming 30% of calories from fat
    }

    private double getActivityFactor() {
        // Implement activity factor calculation based on activity level
        // (Sedentary, Lightly Active, Moderately Active, Very Active)
        return 1.0; // Placeholder, replace with actual calculation
    }
}

