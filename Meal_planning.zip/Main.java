import javax.swing.*;

public class Main{

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            
			// Create an instance of the Users class
            Users users = new Users();

            
            LoginWindow loginWindow = new LoginWindow(users);
            // Set the window to be visible
            loginWindow.setVisible(true);
			
			InputGUI inputGUI = new InputGUI();
            
			
			CaloriesGUI caloriesGUI = new CaloriesGUI(2000, 250, 75, 90);
            MealsGUI mealsGUI=new MealsGUI();
			MealNamesGUI mealNamesGUI=new MealNamesGUI("Breakfast");
			MealDetailsGUI mealDetailsGUI = new MealDetailsGUI("Oatmeal with Fruits");
        });
    }
}

