import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MealsGUI extends JFrame {
	

    private JLabel imgLabel;
    private ImageIcon img;

    public MealsGUI() {
        setTitle("Meal");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        img = new ImageIcon("Food8.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(400, 0, 1000, 800);
        panel.add(imgLabel);

        JLabel titleLabel = new JLabel("Select your Meal!");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 34));
        titleLabel.setBounds(100, 30, 350, 70);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);

        panel.setBackground(Color.BLACK);

        JButton breakfastButton = new JButton("Breakfast");
        breakfastButton.setBounds(130, 200, 250, 70);
		breakfastButton.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 20));
        breakfastButton.setBackground(Color.ORANGE);
        breakfastButton.setForeground(Color.BLACK);
        breakfastButton.addActionListener(e -> showMealNames("Breakfast"));
        panel.add(breakfastButton);

        JButton lunchButton = new JButton("Lunch");
        lunchButton.setBounds(130, 320, 250, 70);
		lunchButton.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 20));
        lunchButton.setBackground(Color.ORANGE);
        lunchButton.setForeground(Color.BLACK);
        lunchButton.addActionListener(e -> showMealNames("Lunch"));
        panel.add(lunchButton);

        JButton dinnerButton = new JButton("Dinner");
        dinnerButton.setBounds(130, 440, 250, 70);
		dinnerButton.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 20));
        dinnerButton.setBackground(Color.ORANGE);
        dinnerButton.setForeground(Color.BLACK);
        dinnerButton.addActionListener(e -> showMealNames("Dinner"));
        panel.add(dinnerButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(130, 570, 250, 40);
		backButton.setFont(new Font("Monaco", Font.ITALIC, 20));
        backButton.setBackground(Color.BLUE);
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> goBack());
        panel.add(backButton);

        add(panel);
    }

    private void showMealNames(String mealType) {
        MealNamesGUI mealNamesGUI = new MealNamesGUI(mealType);
        mealNamesGUI.setVisible(true);

        this.dispose(); // Close the current MealsGUI after proceeding
    }

    private void goBack() {
        // Implement logic to go back to the CaloriesGUI
        CaloriesGUI caloriesGUI = new CaloriesGUI(0, 0, 0, 0); // Pass default values or retrieve them as needed
        caloriesGUI.setVisible(true);

        this.dispose(); // Close the current MealsGUI
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            MealsGUI mealsGUI = new MealsGUI();
            mealsGUI.setVisible(true);
        });
    }
}

